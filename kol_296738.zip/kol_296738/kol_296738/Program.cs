﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace kol_296738
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] słowa =
            {
            "czereśnia", "jabłko", "borówka", "wiśnia",
            "jagoda", "gruszka", "śliwka", "malina"
            };

            var listas = from slowo in słowa
                                        where slowo.Length == 6
                                        select slowo;

            List<Słowo> lista = new List<Słowo>();

            foreach (String s in listas)
            {
            
                string samo = "aeuyoi";

                int l =
                  (from ch in s.ToLowerInvariant()
                   where samo.Contains(ch)
                   select ch).Count();

                lista.Add(new Słowo { ts = s, ds = s.Length, ls = l, ps = l / s.Length });

            }

            foreach (Słowo s in lista)
            {
                Console.WriteLine(s.ToString());
            }

        }
        public struct Słowo
        {
            public String ts;
            public int ds;
            public int ls;
            public double ps;

            public override string ToString()
            {
                return "" + ts + " - " + ds + " - " + ls + " - " + ps;
            }

        }
    }
}
